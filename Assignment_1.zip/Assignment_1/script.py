#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    Created on Thu Oct 11 12:08:20 2018

    @author: dodo
    """

import cv2
import numpy as np
#   import matplotlib.ppylot as plt

path = "/Users/dodo/GUC/sem_9/Computer_Vision/Assignments/Assignment_1/A1I"
#file_to_save = "/Users/dodo/GUC/sem_9/Computer_Vision/Assignments/Assignment_1/out_imgs"

def edit_pic(imgpath):
    
    # Read the image
    img = cv2.imread(imgpath, 1)
    
    # Get the shape of the image.
    rows, cols, channels = img.shape
    
    # alpha for contrast.
    # beta  for brightness.
    alpha_right = 1
    alpha_left = 3
    beta = 0
    
    # Calculate the exact half of the image.
    half_cols = int(cols / 2)
    
    # Do copy two times in order to do each half brightness alone and then combine in one image.
    left = cv2.imread(imgpath, 1)
    right = cv2.imread(imgpath, 1)
    
    # Setting the other half of each half to be 0 in order to do change
    # in brightness and then add both halves together to output the needed image.
    left[:,half_cols:]=[0,0,0]
    right[:, :half_cols] = [0, 0, 0]
    
    # new_image = np.zeros(img.shape, img.dtype)
    # for y in range(rows):
    #  for x in range(half_cols):
    #     for c in range(channels):
    #        new_image[y, x, c] = np.clip(alpha_high * img[y, x, c] + beta, 0, 255)
    #       new_image[y, x+half_cols, c] = np.clip(alpha_low * img[y, x+half_cols, c] + beta, 0, 255)
    
 
    # Do the brightness change.
    new_image_left = cv2.convertScaleAbs(left, alpha=alpha_left, beta=beta)
    new_image_right = cv2.convertScaleAbs(right, alpha=alpha_right, beta=beta)
    
    # Combine the both new left and right images.
    res = new_image_left+new_image_right
    cv2.imshow('output', res)
    print(res.shape)
    #cv2.imwrite(file_to_save + '.png', res)
    return res

def rotateImage(imgpath, angle):
    image =cv2.imread(imgpath, 1)
    image_center = tuple(np.array(image.shape[1::-1]) / 2)
    rot_mat = cv2.getRotationMatrix2D(image_center, angle, 1.0)
    result = cv2.warpAffine(image, rot_mat, image.shape[1::-1], flags=cv2.INTER_LINEAR)
    return result


def geom_editing(imgpath):
    img = cv2.imread(imgpath, 1)
    rows, cols, channels = img.shape
    
    # Rotating 180degree around the origin
    M = cv2.getRotationMatrix2D((cols / 2, rows / 2), 180, 1)
    edited = cv2.warpAffine(img, M, (cols, rows),flags=cv2.INTER_LINEAR)
   
    # flipping around x-axis
    im2 = cv2.flip(edited, 0)
    # Resizing image to have the same shape of the image Q10.
    resized_image = cv2.resize(im2, (1121, 788))
    
    print(im2.shape)
    #cv2.imshow('f',im2)
    
    res=  rotateImage(imgpath,180)
    im2 = cv2.flip(res, 0)
        #cv2.imshow('f',resized_image)

    return resized_image


def merging_Q1(img1,img2):
    alpha= 1
    beta = ( 1.0 - alpha );
    res =cv2.addWeighted( img1, alpha, img2, beta, 0.0)
    cv2.imshow('output', res)



def rotateImage2(image, angle):
    rows,cols,_ = image.shape
    rot_mat = cv2.getRotationMatrix2D(((cols/2,rows/2)), angle, 1.0)
    result = cv2.warpAffine(image, rot_mat, (cols,rows))
    return result


def four_point_transform(image, rect):
    # obtain a consistent order of the points and unpack them
    # individually
    (tl, tr, br, bl) = rect
    
    # compute the width of the new image, which will be the
    # maximum distance between bottom-right and bottom-left
    # x-coordiates or the top-right and top-left x-coordinates
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))
    
    # compute the height of the new image, which will be the
    # maximum distance between the top-right and bottom-right
    # y-coordinates or the top-left and bottom-left y-coordinates
    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    maxHeight = max(int(heightA), int(heightB))
    
    # now that we have the dimensions of the new image, construct
    # the set of destination points to obtain a "birds eye view",
    # (i.e. top-down view) of the image, again specifying points
    # in the top-left, top-right, bottom-right, and bottom-left
    # order
    dst = np.array([
                    [0, 0],
                    [maxWidth - 1, 0],
                    [maxWidth - 1, maxHeight - 1],
                    [0, maxHeight - 1]], dtype = "float32")
        
    # compute the perspective transform matrix and then apply it
    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
                    
    # return the warped image
    return warped , maxWidth,maxHeight


def rotate_bound(image, angle):
    # grab the dimensions of the image and then determine the
    # center
    (h, w) = image.shape[:2]
    (cX, cY) = (w // 2, h // 2)

    # grab the rotation matrix (applying the negative of the
    # angle to rotate clockwise), then grab the sine and cosine
    # (i.e., the rotation components of the matrix)
    M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
    cos = np.abs(M[0, 0])
    sin = np.abs(M[0, 1])

    # compute the new bounding dimensions of the image
    nW = int((h * sin) + (w * cos))
    nH = int((h * cos) + (w * sin))

    # adjust the rotation matrix to take into account translation
    M[0, 2] += (nW / 2) - cX
    M[1, 2] += (nH / 2) - cY

    # perform the actual rotation and return the image
    return cv2.warpAffine(image, M, (nW, nH))

def main():
  #  imgpath = path+"/Q1I2.jpg"
   # bld = path+"/Q1O.jpg"

  #  img = cv2.imread(imgpath , 1)

   # img = geom_editing(imgpath)

    # rows,cols,channels = img.shape
    # print(rows,cols,channels)

   # a = 0.5
  #  org = cv2.addWeighted(bld, 1 / a, img, 1 - 1 / a, 0)

  #  cv2.imshow('Lena', org)

    #   cv2.imwrite('pop.png',img)

    #imgpath =
    #img1 = cv2.imread(imgpath, 1)
    
    # Task 1
    #img1 = edit_pic(path +"/Q1I1.png")
    #img2 =  geom_editing(path+"/Q1I2.jpg")
    #merging_Q1(img1,img2)
    
    
    
    
    
    #Task2
    #imgpath = path+"/Q1I2.jpg"
    #img1 = cv2.imread(path + "/Q2I2.jpg")
    img2 = cv2.imread(path + "/Q2I1.jpg")
    #resized_image = cv2.resize(img2, (91, 141),cv2.INTER_LINEAR)
    
    #y_offset = 377
    #x_offset = 1219
    #img1[y_offset:y_offset+resized_image.shape[0], x_offset:x_offset+resized_image.shape[1]] = resized_image
    
    #cv2.imshow('temp',img1)
  
    #resized_image = cv2.resize(img2, (340, 435),cv2.INTER_LINEAR)
    #imgpath=path + "/Q2I1.jpg"
    #resized_image  = rotateImage2(resized_image,-10)
    #y_offset = 90
    #x_offset = 370
    #img1[y_offset:y_offset+resized_image.shape[0], x_offset:x_offset+resized_image.shape[1]] = resized_image
    img = cv2.imread(path+"/Q2I3.jpg")
    img2 = cv2.imread(path + "/Q2I1.jpg")
    rows,columns , channels = img.shape

    boom = rotate_bound(img,-6)
    boom = rotate_bound(boom,6)
    #cv2.imshow('bbom',boom)
    ro,col,ch = boom.shape
    
    #print((rows,ro), (columns , col))
    resized_image = cv2.resize(boom, (columns,rows))
    rows,columns , channels = resized_image.shape
    print(rows,columns)
    #cv2.imshow('resized',resized_image)
  
    #matrix = cv2.getAffineTransform(pt3,pt4)
    #img1 = cv2.warpAffine(img1,matrix , (columns,rows))
    

    #matrix = cv2.getAffineTransform(pt1,pt2)
    
    #img1 = cv2.warpAffine(img1,matrix , (columns,rows))
    
    
    #Y =502
    #X =714
    
    pt_old = np.float32([[371,93],[704,127],[664,558],[325,525]])
    wrap,maxWidth,maxHeight = four_point_transform(img,pt_old)
    #cv2.imshow('wrap',wrap)

   #pt_new = np.float32([[371,93],[704,93],[704,525],[371,525]])
    #matrix = cv2.getPerspectiveTransform(pt_old,pt_new)
    #img1 = cv2.warpPerspective(img,matrix , (columns,rows))

    # x = 345 y = 110
    img2 = cv2.resize(img2, (maxWidth,maxHeight ),cv2.INTER_LINEAR)

    y_offset = 110
    x_offset = 345
    boom[y_offset:y_offset+img2.shape[0], x_offset:x_offset+img2.shape[1]] = img2
    bor = rotateImage2(boom,-3)
    
    #cv2.imshow('wrap',boom)
    
    y_offset = 93
    x_offset = 371
    img[y_offset:y_offset+wrap.shape[0], x_offset:x_offset+wrap.shape[1]] = wrap
    
    #img= rotateImage2(wrap,10)
    #cv2.imshow('wrap',img)
    
    #matrix = cv2.getPerspectiveTransform(pt_new,pt_old)
    #img1 = cv2.warpPerspective(img1,matrix , (columns,rows),cv2.WARP_INVERSE_MAP,cv2.BORDER_TRANSPAREN)
    
    
    #pt_old = np.float32([[371,93],[704,127],[325,525]])
    #pt_new = np.float32([[371,93],[704,93],[371,525]])
    #matrix = cv2.getAffineTransform(pt_old,pt_new)
    #img1 = cv2.warpAffine(img1,matrix , (columns,rows))
    #matrix = cv2.getAffineTransform(pt_new,pt_new)
    #img1 = cv2.warpAffine(img1,matrix , (columns,rows))
    

    #img = cv2.imread(path+"/Q3I1.jpg")
    #pt_old = np.float32([[155,33],[475,60],[470,360],[150,400]])
    #wrap,maxWidth,maxHeight = four_point_transform(img,pt_old)
    #cv2.imshow('wrap',wrap)

    
    
    
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()


# 372 115

